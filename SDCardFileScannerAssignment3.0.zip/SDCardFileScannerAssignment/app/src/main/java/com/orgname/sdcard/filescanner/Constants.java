package com.orgname.sdcard.filescanner;

public class Constants {
    public static int ONE_KB = 1024;
    public static String GB = "Gb";
    public static String KB = "Kb";
    public static String MB = "Mb";
    public static String TWO_DECIMALFORMATER = "%.2f";
}
